#!/usr/bin/python
# -*- coding: utf-8 -*-

"""Dieses Modul enthält eine Klasse um Audiodateien zu verarbeiten (momentan FLAC und MP3). """
from dacapo import errorhandling
try:
	from dacapo.metadaten import audiofile
except ImportError, err:
	errorhandling.Error.show()
	sys.exit(2)


class Mp3File(audiofile.AudioFile):

	def __init__(self, playerGUI, filename):
		super(VorbisFile, self).__init__(playerGUI, filename)


